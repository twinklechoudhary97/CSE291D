#!/usr/bin/env python

# --
#                 - Mellanox Confidential and Proprietary -
#
# Copyright (C) Jan 2013, Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
#
# Except as specifically permitted herein, no portion of the information,
# including but not limited to object code and source code, may be reproduced,
# modified, distributed, republished or otherwise exploited in any form or by
# any means for any purpose without the prior written permission of Mellanox
# Technologies Ltd. Use of software subject to the terms and conditions
# detailed in the file "LICENSE.txt".
# --
# Author: Ahmed Awwad   ahmadaw@mellanox.com -- created: 2017/March

# Python Imports
import os
# local imports
from common_meta import MSingletonMeta


class PrintData(object):
    """
    Class for printing Data
    """
    __metaclass__ = MSingletonMeta

    def __init__(self, withDebug=False):
        """
        Constructor for PrintData
        """
        self.__withDebug = withDebug

    def printOutput(self, output):
        """
        Print Data to output
        """
        if self.__withDebug:
            print("-D- %s" % output)
