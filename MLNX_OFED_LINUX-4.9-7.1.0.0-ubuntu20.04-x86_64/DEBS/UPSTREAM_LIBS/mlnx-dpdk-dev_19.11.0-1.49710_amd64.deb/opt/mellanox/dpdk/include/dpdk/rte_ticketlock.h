/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2019 Arm Limited
 */

#ifndef _RTE_TICKETLOCK_X86_64_H_
#define _RTE_TICKETLOCK_X86_64_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "generic/rte_ticketlock.h"

#ifdef __cplusplus
}
#endif

#endif /* _RTE_TICKETLOCK_X86_64_H_ */
