/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2015 Intel Corporation
 */

#ifndef _MAIN_H_
#define _MAIN_H_

int main(int argc, char *argv[]);

#endif /* ifndef _MAIN_H_ */
