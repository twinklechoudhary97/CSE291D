/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2018 Intel Corporation
 */

#ifndef _INCLUDE_COMMON_H_
#define _INCLUDE_COMMON_H_

#ifndef NAME_SIZE
#define NAME_SIZE                                            64
#endif

#endif /* _INCLUDE_COMMON_H_ */
