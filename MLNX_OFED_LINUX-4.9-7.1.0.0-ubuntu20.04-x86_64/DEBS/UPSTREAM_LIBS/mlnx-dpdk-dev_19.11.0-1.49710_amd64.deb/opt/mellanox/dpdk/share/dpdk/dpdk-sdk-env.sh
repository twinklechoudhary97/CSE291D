export RTE_TARGET="x86_64-native-linux-gcc"
export RTE_SDK="/opt/mellanox/dpdk/share/dpdk/"
export RTE_INCLUDE="/opt/mellanox/dpdk/include/dpdk"
