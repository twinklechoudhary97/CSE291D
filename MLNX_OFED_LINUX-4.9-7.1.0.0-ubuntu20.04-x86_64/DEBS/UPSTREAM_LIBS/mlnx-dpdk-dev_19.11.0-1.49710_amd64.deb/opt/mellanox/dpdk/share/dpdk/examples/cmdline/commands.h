/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2014 Intel Corporation
 */

#ifndef _COMMANDS_H_
#define _COMMANDS_H_

extern cmdline_parse_ctx_t main_ctx[];

#endif /* _COMMANDS_H_ */
