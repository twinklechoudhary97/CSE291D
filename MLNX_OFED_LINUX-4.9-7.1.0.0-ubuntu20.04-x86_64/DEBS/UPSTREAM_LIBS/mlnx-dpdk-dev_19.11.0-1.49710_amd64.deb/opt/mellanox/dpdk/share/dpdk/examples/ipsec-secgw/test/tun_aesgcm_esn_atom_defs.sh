#! /bin/bash
# SPDX-License-Identifier: BSD-3-Clause

. ${DIR}/tun_aesgcm_esn_defs.sh

SGW_CMD_XPRM='-e -a -w 300 -l'
